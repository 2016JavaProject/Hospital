package business.action.cashier;

import java.util.ArrayList;
import java.util.List;

import business.entity.cashier.CashierEntity;
import business.service.cashier.CashierService;

public class CashierAction {
	public void addCashierAction(CashierEntity cashierEntity) {
		CashierService cashierService = new CashierService();
		cashierService.addCashierService(cashierEntity);
	}

	/**
	 * 删除一条CashierEntity记录
	 */
	public void delCashierAction(String mId) {
		CashierService cashierService = new CashierService();
		cashierService.delCashierService(mId);
	}


	/**
	 * 更新一条CashierEntity记录
	 */
	public void updateCashierAction(CashierEntity cashierEntity) {
		CashierService cashierService = new CashierService();
		cashierService.updateCashierService(cashierEntity);
	}

	/**
	 * 查找CashierId为mId的记录
	 */
	public CashierEntity findCashierAction(String mId) {
		CashierService cashierService = new CashierService();
		CashierEntity cashierEntity = cashierService.findCashierService(mId);
		return cashierEntity;
	}

	/**
	 * 查找所有CashierEntity的记录
	 */
	public List<CashierEntity> listallCashierAction() {
		CashierService cashierService = new CashierService();
		List<CashierEntity> cashierList = new ArrayList();
		cashierList = cashierService.listallCashierService();
		return cashierList;
	}
}
