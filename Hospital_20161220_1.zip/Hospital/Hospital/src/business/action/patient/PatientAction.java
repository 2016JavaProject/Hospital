package business.action.patient;

import java.util.ArrayList;
import java.util.List;

import business.entity.patient.PatientEntity;
import business.service.patient.PatientService;

public class PatientAction {

	/**
	 * 增加一条PatientEntity记录
	 */
	public void addPatientAction(PatientEntity patientEntity) {
		PatientService patientService = new PatientService();
		patientService.addPatientService(patientEntity);
	}

	/**
	 * 删除一条PatientEntity记录
	 */
	public void delPatientAction(String mId) {
		PatientService patientService = new PatientService();
		patientService.delPatientService(mId);
	}


	/**
	 * 更新一条PatientEntity记录
	 */
	public void updatePatientAction(PatientEntity patientEntity) {
		PatientService patientService = new PatientService();
		patientService.updatePatientService(patientEntity);
	}

	/**
	 * 查找PatientId为mId的记录
	 */
	public PatientEntity findPatientAction(String mId) {
		PatientService patientService = new PatientService();
		PatientEntity patientEntity = patientService.findPatientService(mId);
		return patientEntity;
	}

	/**
	 * 查找所有PatientEntity的记录
	 */
	public List<PatientEntity> listallPatientAction() {
		PatientService patientService = new PatientService();
		List<PatientEntity> patientList = new ArrayList();
		patientList = patientService.listallPatientService();
		return patientList;
	}
}
