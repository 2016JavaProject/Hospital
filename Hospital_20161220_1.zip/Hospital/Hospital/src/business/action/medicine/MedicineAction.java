package business.action.medicine;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import business.entity.medicine.MedicineEntity;
import business.service.medicine.MedicineService;
import Comm.DB.MySQLHelper;

public class MedicineAction {
//	public void testForData() {
//		MedicineService medicineService = new MedicineService();
//		List<MedicineEntity> medicineList = new ArrayList();
////		medicineList = medicineService.ListAll();
//		
////		System.out.println("123");
//		
//	}
	
	/**
	 * 增加一条MedicineEntity记录
	 */
	public void addMedicineAction(MedicineEntity medicineEntity) {
		MedicineService medicineService = new MedicineService();
		medicineService.addMedicineService(medicineEntity);
	}
	
	/**
	 * 删除一条MedicineEntity记录
	 */
	public void delMedicineAction(String mId) {
		MedicineService medicineService = new MedicineService();
		medicineService.delMedicineService(mId);
	}
	
	/**
	 * 将一条MedicineEntity记录失效
	 */
	public void disableMedicineAction(String mId){
		MedicineService medicineService = new MedicineService();
		medicineService.disabledMedicineService(mId);
	}
	
	/**
	 * 更新一条MedicineEntity记录
	 */
	public void updateMedicineAction(MedicineEntity medicineEntity) {
		MedicineService medicineService = new MedicineService();
		medicineService.updateMedicineService(medicineEntity);
	}
	
	/**
	 * 查找MedicineId为mId的记录
	 */
	public MedicineEntity findMedicineAction(String mId) {
		MedicineService medicineService = new MedicineService();
		MedicineEntity medicineEntity = medicineService.findMedicineService1(mId);
		return medicineEntity;
	}
	
	/**
	 * 查找所有MedicineEntity的记录
	 */
	public List<MedicineEntity> listallMedicineAction() {
		MedicineService medicineService = new MedicineService();
		List<MedicineEntity> medicineList = new ArrayList();
		medicineList = medicineService.listallMedicineService();
		return medicineList;
	}
	
}
