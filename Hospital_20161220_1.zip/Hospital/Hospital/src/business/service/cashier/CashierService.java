package business.service.cashier;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Comm.DB.MySQLHelper;
import business.entity.cashier.CashierEntity;

public class CashierService {

	public void addCashierService(CashierEntity cashierEntity){
		String sql = "INSERT INTO t_cashier(id, name, tel, age, comm, dept,deptName) VALUES(?,?,?,?,?,?,?)";
		String[] parameters = {cashierEntity.getId(),cashierEntity.getName(),cashierEntity.getTel(),Integer.toString(cashierEntity.getAge()),cashierEntity.getComm(),Integer.toString(cashierEntity.getDept()),cashierEntity.getDeptName()};
		MySQLHelper.executeUpdate(sql, parameters);
	}
	
	public void delCashierService (String id) {
		String sql = "delete from t_cashier WHERE id = ?";
		String[] parameters = {id};
		MySQLHelper.executeUpdate(sql, parameters);
	}
	
//	public void DelCashierService (CashierEntity cashierEntity) {
//		String sql = "UPDATE t_cashier SET isEnabled = 0 WHERE id = ?";
//		String[] parameters = {cashierEntity.getId()};
//		MySQLHelper.executeQuery(sql, parameters);
//	}
	
	public void updateCashierService (CashierEntity cashierEntity) {
		String sql = "UPDATE t_cashier SET name = ?, tel = ?, age = ?, comm = ?, dept = ?, deptName = ? WHERE id = ?";
		String[] parameters = {cashierEntity.getName(),cashierEntity.getTel(),Integer.toString(cashierEntity.getAge()),cashierEntity.getComm(),Integer.toString(cashierEntity.getDept()),cashierEntity.getDeptName(),cashierEntity.getId()};
		MySQLHelper.executeUpdate(sql, parameters);
	}
	
	public CashierEntity findCashierService (String id) {
		String sql = "SELECT * FROM t_cashier WHERE ID = ? ";
		String[] parameters = {id};
		ResultSet rs = MySQLHelper.executeQuery(sql, parameters);
		CashierEntity cashierEntity = new CashierEntity();
		try {
			if(rs.next()){
				cashierEntity.setId(rs.getString("id"));
				cashierEntity.setName(rs.getString("name"));
				cashierEntity.setTel(rs.getString("tel"));
				cashierEntity.setAge(rs.getInt("age"));
				cashierEntity.setComm(rs.getString("comm"));
				cashierEntity.setDeptName(rs.getString("deptName"));
				cashierEntity.setDept(rs.getInt("dept"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cashierEntity;

	}
	
	public ArrayList<CashierEntity> listallCashierService () {
		String sql = "SELECT * FROM t_cashier where 1 = 1";
		ResultSet rs = MySQLHelper.executeQuery(sql, null);
		ArrayList<CashierEntity> list = new ArrayList<>();
		try {
			while(rs.next()) {
				CashierEntity cashierEntity = new CashierEntity();
				cashierEntity.setId(rs.getString("id"));
				cashierEntity.setName(rs.getString("name"));
				cashierEntity.setTel(rs.getString("tel"));
				cashierEntity.setAge(rs.getInt("age"));				
				cashierEntity.setComm(rs.getString("comm"));
				cashierEntity.setDeptName(rs.getString("deptName"));
				cashierEntity.setDept(rs.getInt("dept"));
				list.add(cashierEntity);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
