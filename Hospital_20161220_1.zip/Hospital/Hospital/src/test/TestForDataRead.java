package test;

import java.util.ArrayList;
import java.util.List;

import business.action.medicine.MedicineAction;
import business.entity.medicine.MedicineEntity;

public class TestForDataRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		/**
		 * addMedicine测试
		 */
//		MedicineAction medicineAction = new MedicineAction();
//		MedicineEntity medicineEntity = new MedicineEntity();	
//		medicineEntity.setId("20161215-1");
//		medicineEntity.setName("name20161215-1");
//		medicineEntity.setPrice((float) 201612.151);
//		medicineEntity.setMethods(1);
//		medicineEntity.setIsEnabled(1);
//		medicineEntity.setUpdateTime("20161215-1");
//		medicineEntity.setNorms(10);
//		medicineEntity.setNum(1000);
//		medicineEntity.setSpecNum(5);
//		medicineEntity.setComm("20161215-1备注");	
//		medicineAction.addMedicineAction(medicineEntity);
		
		/**
		 * delMedicine测试
		 */
//		MedicineAction medicineAction = new MedicineAction();
//		MedicineEntity medicineEntity = new MedicineEntity();
//		medicineEntity.setId("20161215-1");
//		medicineAction.delMedicineAction(medicineEntity.getId());
		
		/**
		 * disableMedicine测试
		 */
//		MedicineAction medicineAction = new MedicineAction();
//		MedicineEntity medicineEntity = new MedicineEntity();
//		medicineEntity.setId("20161215-1");
//		medicineAction.disableMedicineAction(medicineEntity.getId());
		
		/**
		 * updateMedicine测试
		 */
//		MedicineAction medicineAction = new MedicineAction();
//		MedicineEntity medicineEntity = new MedicineEntity();
//		medicineEntity.setId("20161215-1");
//		medicineEntity.setName("name20161215-1-2");
//		medicineEntity.setPrice((float) 201612.1512);
//		medicineEntity.setMethods(1);
//		medicineEntity.setIsEnabled(1);
//		medicineEntity.setUpdateTime("20161215-1-2");
//		medicineEntity.setNorms(10);
//		medicineEntity.setNum(1000);
//		medicineEntity.setSpecNum(5);
//		medicineEntity.setComm("20161215-1备注-2");		
//		medicineAction.updateMedicineAction(medicineEntity);
		
		/**
		 * findMedicine测试
		 */
//		MedicineAction medicineAction = new MedicineAction();
//		MedicineEntity medicineEntity = new MedicineEntity();
//		String mId = "1";
//		medicineEntity = medicineAction.findMedicineAction(mId);
//		System.out.println(medicineEntity.getId() + "\t"+ medicineEntity.getName() + "\t" + medicineEntity.getPrice() + "\t" + medicineEntity.getMethods() + "\t" + medicineEntity.getIsEnabled() + "\t" + medicineEntity.getUpdateTime() + "\t" + medicineEntity.getNorms() + "\t" + medicineEntity.getNum() + "\t" + medicineEntity.getSpecNum() + "\t" + medicineEntity.getComm());
	
		/**
		 * listallMedicine测试
		 */
//		MedicineAction medicineAction = new MedicineAction();
//		List<MedicineEntity> medicineList = new ArrayList();
//		medicineList = medicineAction.listallMedicineAction();			
//		for(int i=0; i<medicineList.size(); i++) {
//			System.out.println(medicineList.get(i).getId() + "\t"+ medicineList.get(i).getName() + "\t" + medicineList.get(i).getPrice() + "\t" + medicineList.get(i).getMethods() + "\t" + medicineList.get(i).getIsEnabled() + "\t" + medicineList.get(i).getUpdateTime() + "\t" + medicineList.get(i).getNorms() + "\t" + medicineList.get(i).getNum() + "\t" + medicineList.get(i).getSpecNum() + "\t" + medicineList.get(i).getComm());		
//		}
		
		
		
	}

}
